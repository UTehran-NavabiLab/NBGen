============= What's there ==============
The released libraries comprise of 14nm CMOS devices operating at 0.55V supply voltage level for near-threshold operation, 0.70V for super-threshold operation, or at 0.80V supply voltage level for boosting operation.

The released libraries comprise the following files:

cmos14nm_055.lib: Standard cell library of 14nm CMOS devices at 0.55V supply voltage level.
cmos14nm_070.lib: Standard cell library of 14nm CMOS devices at 0.70V supply voltage level.
cmos14nm_080.lib: Standard cell library of 14nm CMOS devices at 0.80V supply voltage level.

And the corresponding .db files for circuit synthesis.

============== Change log ===============
09/10/2014 - fix cell areas.
08/20/2014 - initial release.

============== Contact us ===============
If you have questions or encounter problems when using these cell libraries, you may contact Yanzhi Wang (yanzhiwa@usc.edu) for help.