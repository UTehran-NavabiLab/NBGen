The released libraries comprise of 16nm CMOS devices operating at 0.50V supply voltage level for near-threshold operation, and 0.70V for super-threshold operation. The released libraries are based on the 16nm CMOS PTM device model developed by Prof. Yu Cao and his team at ASU.

The released libraries comprise the following files:

ptm16nm050.lib: Standard cell library of 16nm CMOS devices at 0.50V supply voltage level.
ptm16nm070.lib: Standard cell library of 16nm CMOS devices at 0.70V supply voltage level.