The released libraries comprise of 5nm FinFET devices operating at 0.3V supply voltage level for near-threshold operation, and 0.45V for super-threshold. The released libraries are based on the 5nm FinFET device model developed by Prof. Kaushik Roy and his team at Purdue University.

The released libraries comprise the following files:

FinFET5nm030.lib: Standard cell library of 5nm FinFET devices at 0.30V supply voltage level.
FinFET5nm045.lib: Standard cell library of 5nm FinFET devices at 0.45V supply voltage level.